module.exports = {
  plugins: ["autoprefixer"],
};
