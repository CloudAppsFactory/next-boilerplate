declare namespace IFooter {
    export interface IProps {}
}

export { IFooter };
