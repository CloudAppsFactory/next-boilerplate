import * as React from "react";

export const LineArt: React.FunctionComponent = (): JSX.Element => {
    return (
        <div style={{justifyContent: 'flex-end',display: 'flex'}}>
            <img src="/images/svg/lineart1.svg" width="auto" height="250px" />
        </div>
    );
};